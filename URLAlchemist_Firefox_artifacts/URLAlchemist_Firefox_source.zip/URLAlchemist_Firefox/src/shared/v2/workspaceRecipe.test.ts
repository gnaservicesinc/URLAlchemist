import { afterEach, describe, expect, it, vi } from 'vitest';

import { DEFAULT_SETTINGS } from '../constants';
import { createBundledExampleWorkspaces } from './bundledExamples';
import { compileWorkspace } from './compiler';
import {
  previewOllamaWorkspaceDraft,
  requestOllamaWorkspaceDraft,
  workspaceFromOllamaDraft,
} from './ollama';
import type { WorkspaceRecipeV1 } from './workspaceRecipe';
import {
  buildWorkspaceRecipeContext,
  materializeWorkspaceRecipe,
  parseWorkspaceRecipe,
  workspaceToRecipe,
} from './workspaceRecipe';
import {
  createDefaultContentBlockerWorkspace,
  createDefaultWorkspace,
  createWorkspaceNode,
} from './workspace';

function validRecipe(): WorkspaceRecipeV1 {
  return {
    kind: 'workspace-recipe.v1',
    workspaceType: 'data-modifier',
    name: 'Remove Preview Parameter',
    description: 'Removes the preview query parameter from the current URL.',
    trigger: {
      type: 'INPUT_DATA',
      hotkey: 'Ctrl+Shift+U',
      inputSources: ['url'],
      sourceFilters: [{ source: 'url', pattern: '^https?://' }],
    },
    nodes: [
      {
        id: 'input',
        type: 'DataFlowIn',
        position: { x: 0, y: 100 },
        settings: { locked: true },
      },
      {
        id: 'clean',
        type: 'RegExpression',
        position: { x: 320, y: 100 },
        settings: {
          label: 'Remove preview parameter',
          pattern: '([?&])preview=[^&#]*&?',
          action: 'SUBSTITUTE',
          matchMode: 'STANDARD',
          payload: '$1',
          payloadVars: true,
        },
      },
      {
        id: 'output',
        type: 'DataFlowOut',
        position: { x: 640, y: 100 },
        settings: { locked: true },
      },
    ],
    connections: [
      { from: 'input.url', to: 'clean.input' },
      { from: 'clean.result', to: 'output.url' },
    ],
    viewport: { x: 12, y: -8, zoom: 0.9 },
  };
}

function validCustomBlockRecipe(): WorkspaceRecipeV1 {
  return {
    kind: 'workspace-recipe.v1',
    workspaceType: 'custom-block',
    name: 'Format Text',
    description: 'Formats text through a reusable typed interface.',
    trigger: {
      type: 'NEVER',
      hotkey: 'Ctrl+Shift+F',
      inputSources: ['url'],
      sourceFilters: [],
    },
    nodes: [
      {
        id: 'input',
        type: 'CustomBlockInput',
        settings: {
          label: 'Source text',
          customPortId: 'source',
          customPortLabel: 'Source text',
          customPortDataType: 'string',
          customPortTooltip: 'Text to format.',
        },
      },
      {
        id: 'output',
        type: 'CustomBlockOutput',
        settings: {
          label: 'Formatted text',
          customPortId: 'formatted',
          customPortLabel: 'Formatted text',
          customPortDataType: 'string',
          customPortTooltip: 'The formatted result.',
        },
      },
    ],
    connections: [{ from: 'input.value', to: 'output.value' }],
    customBlock: {
      blockId: 'format-text',
      label: 'Format Text',
      version: 4,
      category: 'convert',
      visibleWorkspaceTypes: ['data-modifier', 'content-blocker'],
      description: 'Formats text.',
      tips: ['Connect a string input.'],
      inputs: [{ id: 'source', label: 'Source text', dataType: 'string', tooltip: 'Text to format.' }],
      outputs: [{ id: 'formatted', label: 'Formatted text', dataType: 'string', tooltip: 'The formatted result.' }],
      fields: [],
    },
  };
}

function ollamaSettings(aiWorkspaceInstructions = 'Prefer small graphs with descriptive labels.') {
  return {
    ollamaEndpoint: DEFAULT_SETTINGS.ollamaEndpoint,
    ollamaModel: 'test-model:latest',
    ollamaTimeoutMs: 5_000,
    aiWorkspaceInstructions,
  };
}

function ollamaResponse(recipe: unknown, headers?: HeadersInit): Response {
  return new Response(JSON.stringify({ response: JSON.stringify(recipe) }), {
    status: 200,
    headers,
  });
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('workspace recipe authoring boundary', () => {
  it('rejects unknown recipe keys and generated-only settings', () => {
    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      unexpectedPolicy: 'ignore-validation',
    })).toThrow('Workspace recipe contains unsupported key');

    const recipeWithUnknownNodeKey = validRecipe();
    expect(() => parseWorkspaceRecipe({
      ...recipeWithUnknownNodeKey,
      nodes: [
        {
          ...recipeWithUnknownNodeKey.nodes[0],
          rawTypeId: 99,
        },
        ...recipeWithUnknownNodeKey.nodes.slice(1),
      ],
    })).toThrow('Recipe node 1 contains unsupported key');

    const recipeWithEmbeddedAsset = validRecipe();
    expect(() => parseWorkspaceRecipe({
      ...recipeWithEmbeddedAsset,
      nodes: [
        {
          ...recipeWithEmbeddedAsset.nodes[0],
          settings: {
            ...recipeWithEmbeddedAsset.nodes[0].settings,
            assetDataBase64: 'untrusted-binary-data',
          },
        },
        ...recipeWithEmbeddedAsset.nodes.slice(1),
      ],
    })).toThrow('assetDataBase64 is generated by URL Alchemist');

    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      nodes: [{ id: 'fetch', type: 'FetchData', settings: { remoteUrl: 123 } }],
      connections: [],
    })).toThrow('remoteUrl must be a string');

    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      nodes: [{ id: 'fetch', type: 'FetchData', settings: { remoteDataType: 'asset', remoteMaxBytes: 50 * 1024 * 1024 } }],
      connections: [],
    })).toThrow(/remoteDataType is unsupported|remoteMaxBytes is outside/);

    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      nodes: [{ id: 'asset-literal', type: 'Constant', settings: { literalDataType: 'asset', literalValue: '' } }],
      connections: [],
    })).toThrow('literalDataType is unsupported');

    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      trigger: {
        type: 'INPUT_DATA',
        sourceFilters: [{ source: 'url', pattern: '^https?://', extra: 'not allowed' }],
      },
    })).toThrow('sourceFilters[0] contains unsupported key');
  });

  it('validates nested custom metadata and one-to-one logical-flow membership', () => {
    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      workspaceType: 'custom-block',
      name: 'Strict Block',
      customBlock: {
        blockId: 'strict-block',
        label: 'Strict Block',
        version: 1,
        category: 'data',
        visibleWorkspaceTypes: ['data-modifier'],
        inputs: [{ id: 'input', label: 'Input', dataType: 'string' }],
        outputs: [{ id: 'output', label: 'Output', dataType: 'string' }],
        fields: [{ id: 123, label: 'Bad field', dataType: 'string' }],
      },
    })).toThrow('customBlock.fields[0].id');

    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      workspaceType: 'custom-block',
      name: 'Strict Block',
      trigger: { type: 'NEVER' },
      nodes: [
        { id: 'input', type: 'CustomBlockInput', settings: { customPortId: 'different', customPortLabel: 'Input', customPortDataType: 'string' } },
        { id: 'output', type: 'CustomBlockOutput', settings: { customPortId: 'result', customPortLabel: 'Result', customPortDataType: 'string' } },
      ],
      connections: [{ from: 'input.value', to: 'output.value' }],
      customBlock: {
        blockId: 'strict-block',
        label: 'Strict Block',
        version: 1,
        category: 'data',
        visibleWorkspaceTypes: ['data-modifier'],
        inputs: [{ id: 'input', label: 'Input', dataType: 'string' }],
        outputs: [{ id: 'result', label: 'Result', dataType: 'string' }],
        fields: [],
      },
    })).toThrow('unknown or duplicate port id');

    expect(() => parseWorkspaceRecipe({
      ...validRecipe(),
      nodes: [
        ...validRecipe().nodes,
        { id: 'condition', type: 'Logical' },
        { id: 'branch', type: 'LogicalFlow' },
      ],
      logicalFlows: [
        { id: 'first', conditionNode: 'condition', controlNode: 'branch' },
        { id: 'second', conditionNode: 'condition', controlNode: 'branch' },
      ],
    })).toThrow('reuses a condition or control node');
  });

  it('rejects catch-all Custom Block categories and round-trips matching boundary tooltips', () => {
    const recipe = validCustomBlockRecipe();
    const parsed = parseWorkspaceRecipe(recipe);
    expect(parsed.customBlock?.category).toBe('convert');
    expect(parsed.customBlock?.inputs[0]?.tooltip).toBe('Text to format.');
    expect(parsed.customBlock?.outputs[0]?.tooltip).toBe('The formatted result.');

    const workspace = materializeWorkspaceRecipe(parsed, {
      id: 'format-text-workspace',
      version: 99,
      createdAt: 10,
      updatedAt: 20,
      nodeIdPrefix: 'format-text',
    });
    expect(workspace.metadata.name).toBe('Format Text');
    expect(workspace.metadata.version).toBe(4);
    expect(workspace.customBlock?.label).toBe(workspace.metadata.name);
    expect(workspace.customBlock?.version).toBe(workspace.metadata.version);

    const roundTrip = workspaceToRecipe(workspace);
    expect(roundTrip.customBlock?.inputs[0]?.tooltip).toBe('Text to format.');
    expect(roundTrip.customBlock?.outputs[0]?.tooltip).toBe('The formatted result.');
    expect(roundTrip.nodes.find((node) => node.type === 'CustomBlockInput')?.settings?.customPortTooltip).toBe('Text to format.');
    expect(roundTrip.nodes.find((node) => node.type === 'CustomBlockOutput')?.settings?.customPortTooltip).toBe('The formatted result.');

    expect(() => parseWorkspaceRecipe({
      ...recipe,
      customBlock: { ...recipe.customBlock!, category: 'custom' },
    })).toThrow('customBlock.category is unsupported');

    expect(() => parseWorkspaceRecipe({
      ...recipe,
      name: 'Different workspace name',
    })).toThrow('name and customBlock.label must match');

    expect(() => parseWorkspaceRecipe({
      ...recipe,
      nodes: recipe.nodes.map((node) => node.type === 'CustomBlockInput'
        ? { ...node, settings: { ...node.settings, customPortTooltip: 'Different tooltip.' } }
        : node),
    })).toThrow('mismatched metadata and node tooltips');
  });

  it('materializes, validates, and round-trips a portable recipe without exposing internals', () => {
    const compatibility = {
      chrome: { version: '2.6.1', status: 'supported' as const },
      firefox: { version: '2.6.1', status: 'supported' as const },
    };
    const workspace = materializeWorkspaceRecipe(validRecipe(), {
      id: 'workspace-preserved-id',
      author: 'Recipe Test',
      version: 7,
      createdAt: 123,
      updatedAt: 456,
      compatibility,
      nodeIdPrefix: 'test-recipe',
    });

    expect(workspace.metadata).toMatchObject({
      id: 'workspace-preserved-id',
      author: 'Recipe Test',
      version: 7,
      created_at: 123,
      updated_at: 456,
      compatibility,
    });
    expect(workspace.nodes.map((node) => node.id)).toEqual([
      'test-recipe:input',
      'test-recipe:clean',
      'test-recipe:output',
    ]);
    expect(compileWorkspace(workspace).ok).toBe(true);

    const serialized = workspaceToRecipe(workspace);
    expect(serialized).toMatchObject({
      kind: 'workspace-recipe.v1',
      workspaceType: 'data-modifier',
      name: 'Remove Preview Parameter',
      nodes: [
        { id: 'input', type: 'DataFlowIn' },
        { id: 'clean', type: 'RegExpression' },
        { id: 'output', type: 'DataFlowOut' },
      ],
      connections: [
        { from: 'input.url', to: 'clean.input' },
        { from: 'clean.result', to: 'output.url' },
      ],
    });
    expect(JSON.stringify(serialized)).not.toMatch(/typeId|permissions|riskMetadata|assetDataBase64/);

    const rebuilt = materializeWorkspaceRecipe(serialized, { nodeIdPrefix: 'roundtrip' });
    expect(compileWorkspace(rebuilt).ok).toBe(true);
  });

  it('canonicalizes legacy triggers and supplies a complete machine-readable authoring context', () => {
    const legacy = createDefaultWorkspace();
    legacy.trigger = {
      type: 'ALWAYS',
      scope_regex: '^https://docs\\.example/',
      hotkey: 'Ctrl+Shift+U',
    };
    const recipe = workspaceToRecipe(legacy);
    expect(recipe.trigger.type).toBe('INPUT_DATA');
    expect(recipe.trigger).not.toHaveProperty('scope_regex');
    expect(recipe.trigger.sourceFilters).toContainEqual({ source: 'url', pattern: '^https://docs\\.example/' });

    const context = buildWorkspaceRecipeContext();
    const convert = context.blocks.find((block) => block.type === 'Convert');
    expect(convert?.settingsSchema).toMatchObject({
      convertMode: { type: 'enum' },
    });
    expect(JSON.stringify(convert)).toContain('JSON_TO_DICT');
    expect(Array.isArray(convert?.portVariants)).toBe(true);
    expect(context.recipeShape.trigger).toMatchObject({
      type: ['INPUT_DATA', 'HOTKEY', 'CONTEXT_MENU', 'INTERVAL', 'NEVER'],
      variants: { INTERVAL: { intervalMs: { min: 30_000 } } },
    });
    expect(context.blocks.find((block) => block.type === 'ContentDataIn')?.availability).toContain('unavailable');
    expect(JSON.stringify(context).length).toBeLessThan(256 * 1024);
  });

  it('lets source validation succeed but rejects a recipe that cannot compile', () => {
    const recipe: WorkspaceRecipeV1 = {
      ...validRecipe(),
      nodes: [{ id: 'input', type: 'DataFlowIn' }],
      connections: [],
    };

    const workspace = materializeWorkspaceRecipe(recipe);
    const compiled = compileWorkspace(workspace);
    expect(compiled.ok).toBe(false);
    expect(compiled.validation.errors.join(' ')).toContain('terminal side-effect');
    expect(() => workspaceFromOllamaDraft(recipe, createDefaultWorkspace())).toThrow('AI workspace draft did not compile');
  });
});

describe('full-graph Ollama workspace drafting', () => {
  it('sends editable instructions and a sanitized current graph, then applies a valid complete recipe', async () => {
    const base = createDefaultWorkspace();
    base.metadata = {
      ...base.metadata,
      id: 'keep-this-workspace-id',
      name: 'Current Workspace',
      author: 'Existing Author',
      version: 11,
      created_at: 1_234,
      updated_at: 5_678,
      compatibility: {
        chrome: { version: '2.6.1', status: 'supported' },
        firefoxAndroid: { version: '2.6.1', status: 'source-only' },
      },
    };
    base.nodes.push(createWorkspaceNode('GetImage', { x: 320, y: 300 }, {
      assetUrl: 'https://example.com/reference.png',
      assetName: 'Reference image',
    }));

    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(ollamaResponse(validRecipe()));
    vi.stubGlobal('fetch', fetchMock);
    const instructions = 'Use concise labels. Never add a network block unless requested.';
    const draft = await requestOllamaWorkspaceDraft(
      ollamaSettings(instructions),
      'Remove preview parameters from the current URL.',
      base,
    );

    expect(draft).toEqual(parseWorkspaceRecipe(validRecipe()));
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const requestInit = fetchMock.mock.calls[0]?.[1];
    expect(requestInit).toMatchObject({ redirect: 'error' });
    const requestBody = JSON.parse(String(requestInit?.body)) as { prompt: string };
    const envelope = JSON.parse(requestBody.prompt.split('\n').at(-1) ?? '{}') as {
      userInstructions: string;
      userRequest: string;
      currentWorkspace: {
        name: string;
        nodes: Array<{ type: string; settings?: Record<string, unknown> }>;
      };
      recipeContext: { kind: string; blocks: unknown[] };
    };

    expect(envelope.userInstructions).toBe(instructions);
    expect(envelope.userRequest).toBe('Remove preview parameters from the current URL.');
    expect(envelope.currentWorkspace.name).toBe('Current Workspace');
    expect(envelope.recipeContext.kind).toBe('workspace-recipe.context.v1');
    expect(envelope.recipeContext.blocks.length).toBeGreaterThan(10);
    const imageSettings = envelope.currentWorkspace.nodes.find((node) => node.type === 'GetImage')?.settings;
    expect(imageSettings).toMatchObject({
      assetUrl: 'https://example.com/reference.png',
      assetName: 'Reference image',
    });
    expect(requestBody.prompt).not.toMatch(/typeId|assetDataBase64|assetResourceId/);

    const applied = workspaceFromOllamaDraft(draft, base);
    expect(applied.metadata).toMatchObject({
      id: 'keep-this-workspace-id',
      author: 'Existing Author',
      version: 11,
      created_at: 1_234,
    });
    expect(applied.metadata.compatibility).toBeUndefined();
    expect(applied.metadata.name).toBe('Remove Preview Parameter');
    expect(applied.nodes.map((node) => node.type)).toEqual(['DataFlowIn', 'RegExpression', 'DataFlowOut']);
    expect(compileWorkspace(applied).ok).toBe(true);

    const remoteWorkspace = createBundledExampleWorkspaces().find((candidate) => candidate.metadata.name === 'Confirmed Webhook Test');
    expect(remoteWorkspace).toBeDefined();
    const remotePreview = previewOllamaWorkspaceDraft(workspaceToRecipe(remoteWorkspace!), createDefaultWorkspace());
    expect(remotePreview.risk.highest).toBe('high');
    expect(remotePreview.risk.reasons.length).toBeGreaterThan(0);
    expect(remotePreview.requiredPermissions).toEqual([]);
    expect(remotePreview.sensitiveBehaviors.join(' ')).toContain('POST request');

    const customWorkspace = createBundledExampleWorkspaces().find((candidate) => candidate.workspaceType === 'custom-block');
    expect(customWorkspace).toBeDefined();
    const customPreview = previewOllamaWorkspaceDraft(workspaceToRecipe(customWorkspace!), createDefaultWorkspace());
    expect(customPreview.requiredPermissions).toBeNull();
  });

  it('blocks lossy drafting for embedded assets, local resources, and installed Custom Blocks', async () => {
    const base = createDefaultWorkspace();
    base.nodes.push(createWorkspaceNode('GetImage', { x: 320, y: 300 }, {
      assetName: 'Private image',
      assetDataBase64: 'PRIVATE-EMBEDDED-BYTES',
      assetResourceId: 'PRIVATE-LOCAL-RESOURCE-ID',
    }));
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(ollamaResponse(validRecipe()));
    vi.stubGlobal('fetch', fetchMock);

    expect(() => workspaceToRecipe(base)).toThrow('cannot safely replace workspaces that depend on embedded assets');
    await expect(requestOllamaWorkspaceDraft(
      ollamaSettings(),
      'Replace the graph.',
      base,
    )).rejects.toThrow('cannot safely replace workspaces that depend on embedded assets');
    expect(fetchMock).not.toHaveBeenCalled();

    const unsupportedSetting = createDefaultWorkspace();
    unsupportedSetting.nodes.push(createWorkspaceNode('Confirm', { x: 320, y: 300 }, { alwaysProcess: true }));
    expect(() => workspaceToRecipe(unsupportedSetting)).toThrow('cannot be represented safely in a recipe');
  });

  it('rejects invalid and oversized model responses', async () => {
    const invalidRecipe = {
      ...validRecipe(),
      compilerOverride: { skipSafetyChecks: true },
    };
    const invalidFetch = vi.fn<typeof fetch>().mockResolvedValue(ollamaResponse(invalidRecipe));
    vi.stubGlobal('fetch', invalidFetch);
    await expect(requestOllamaWorkspaceDraft(
      ollamaSettings(),
      'Draft a workspace.',
      createDefaultWorkspace(),
    )).rejects.toThrow('Workspace recipe contains unsupported key');

    const oversizedFetch = vi.fn<typeof fetch>().mockResolvedValue(ollamaResponse({}, {
      'content-length': '2000000',
    }));
    vi.stubGlobal('fetch', oversizedFetch);
    await expect(requestOllamaWorkspaceDraft(
      ollamaSettings(),
      'Draft a workspace.',
      createDefaultWorkspace(),
    )).rejects.toThrow('workspace draft that is too large');
  });

  it('does not draft or apply recipes to content-blocker workspaces', async () => {
    const recipe = validRecipe();
    const contentBlocker = createDefaultContentBlockerWorkspace();
    expect(() => workspaceFromOllamaDraft(recipe, contentBlocker)).toThrow('not content blockers');

    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(ollamaResponse(recipe));
    vi.stubGlobal('fetch', fetchMock);
    await expect(requestOllamaWorkspaceDraft(
      ollamaSettings(),
      'Replace the content blocker.',
      contentBlocker,
    )).rejects.toThrow('data-modifier and custom-block workspaces only');
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
